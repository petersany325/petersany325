@extends('layouts.app')
@section('title', 'تنظیمات | '.shop_name())
@section('page_title', 'تنظیمات')
@section('window_title', 'پنجره تنظیمات سیستم')
@section('content')
<div data-workspace-tabs data-active-tab="{{ $activeTab ?? 'general' }}">
    <div class="ws-tabs">
        <button type="button" class="{{ $activeTab === 'general' ? 'active' : '' }}" data-ws-tab="general">عمومی / تقویم</button>
        <button type="button" class="{{ $activeTab === 'lookups' ? 'active' : '' }}" data-ws-tab="lookups">منوهای پذیرش</button>
        <button type="button" class="{{ $activeTab === 'faults' ? 'active' : '' }}" data-ws-tab="faults">انواع ایراد</button>
        <button type="button" class="{{ $activeTab === 'referrals' ? 'active' : '' }}" data-ws-tab="referrals">نحوه آشنایی</button>
        <button type="button" class="{{ $activeTab === 'invoice' ? 'active' : '' }}" data-ws-tab="invoice">فاکتور / چاپ</button>
        <button type="button" class="{{ $activeTab === 'labels' ? 'active' : '' }}" data-ws-tab="labels">برچسب / بارکد</button>
        <button type="button" class="{{ $activeTab === 'payments' ? 'active' : '' }}" data-ws-tab="payments">پرداخت / زرین‌پال</button>
        <button type="button" class="{{ $activeTab === 'sms' ? 'active' : '' }}" data-ws-tab="sms">پیامک نیازپرداز</button>
        <button type="button" class="{{ $activeTab === 'backup' ? 'active' : '' }}" data-ws-tab="backup">بکاپ دیتابیس</button>
        <button type="button" class="{{ ($activeTab ?? '') === 'seo' ? 'active' : '' }}" data-ws-tab="seo">سئو / گوگل</button>
        <button type="button" class="{{ $activeTab === 'users' ? 'active' : '' }}" data-ws-tab="users">کارتابل کارمند</button>
    </div>
    <div class="ws-panes">
        <div class="ws-pane {{ $activeTab === 'general' ? 'active' : '' }}" data-ws-pane="general">
            <h2>تنظیمات عمومی و تقویم</h2>
            <p class="lead">تاریخ‌های نمایش و ورودی در کل سیستم شمسی (جلالی) هستند. ذخیره در دیتابیس همیشه میلادی می‌ماند.</p>
            <form method="POST" action="{{ route('settings.general') }}" class="panel">
                @csrf
                <input type="hidden" name="settings_tab" value="general">
                <input type="hidden" name="calendar_type" value="jalali">
                <div class="accept-row accept-row-2">
                    <div>
                        <label>نوع تقویم نمایش</label>
                        <input type="text" value="شمسی (جلالی)" disabled>
                        <p class="muted" style="margin:4px 0 0;font-size:11px;">تقویم نمایش سایت روی شمسی قفل است.</p>
                    </div>
                    <div>
                        <label>ارقام تاریخ</label>
                        <select name="calendar_digits">
                            <option value="fa" @selected(($calendar['digits'] ?? 'fa') === 'fa')>فارسی (۱۴۰۴/۰۵/۱۸)</option>
                            <option value="en" @selected(($calendar['digits'] ?? '') === 'en')>انگلیسی (1404/05/18)</option>
                        </select>
                        <p class="muted" style="margin:4px 0 0;font-size:11px;">فیلدهای ورود تاریخ همیشه ارقام انگلیسی می‌گیرند.</p>
                    </div>
                </div>
                <div class="accept-row accept-row-2" style="margin-top:10px;">
                    <div>
                        <label>پیشوند شماره قبض</label>
                        <input type="text" name="receipt_prefix" value="{{ old('receipt_prefix', $receiptPrefix ?? 'R') }}" maxlength="12" dir="ltr" style="text-align:left;" placeholder="مثلاً T-20N یا R" pattern="[A-Za-z0-9\-]*">
                        <p class="muted" style="margin:4px 0 0;font-size:11px;">فقط حروف انگلیسی، عدد و خط تیره. هر تعمیرگاه پیشوند خودش را دارد؛ پیش‌فرض نصب‌های جدید: R</p>
                    </div>
                    <div>
                        <label>نمونه قبض بعدی</label>
                        <input type="text" value="{{ $receiptPrefixSample ?? (($receiptPrefix ?? 'R').'1000') }}" readonly dir="ltr" style="text-align:left;">
                        <p class="muted" style="margin:4px 0 0;font-size:11px;">شماره واقعی از آخرین قبض همین پیشوند ادامه می‌یابد.</p>
                    </div>
                </div>
                <div class="panel" style="margin-top:10px;background:#f3f7ff;border-color:#b7c8e8;">
                    <strong>نمونه نمایش فعلی:</strong>
                    <div style="margin-top:6px;font-size:14px;" dir="ltr">{{ jalali_like(now()) }}</div>
                    <div class="muted" style="margin-top:4px;font-size:11px;">ساعت سیستم: Asia/Tehran</div>
                </div>
                <div class="actions" style="margin-top:10px;">
                    <button class="btn btn-primary" type="submit">ذخیره تنظیمات عمومی</button>
                </div>
            </form>
        </div>

        <div class="ws-pane {{ $activeTab === 'lookups' ? 'active' : '' }}" data-ws-pane="lookups">
            <h2>منوهای پذیرش</h2>
            <p class="lead">از لیست کشویی مورد را انتخاب کنید، سپس ویرایش، فعال/غیرفعال یا حذف کنید. برای مورد جدید، «— جدید —» را بگذارید.</p>

            @foreach($lookups as $groupKey => $group)
                <div class="lookup-editor panel" data-lookup-editor data-base-url="{{ url('settings/lookups') }}">
                    <h3>{{ $group['label'] }}</h3>
                    <div class="accept-row accept-row-4" style="margin-bottom:6px;">
                        <div style="grid-column:1/-1">
                            <label>انتخاب از منو</label>
                            <select class="lookup-select">
                                <option value="">— جدید —</option>
                                @foreach($group['items'] as $item)
                                    <option value="{{ $item->id }}"
                                            data-name="{{ $item->name }}"
                                            data-sort="{{ $item->sort_order }}"
                                            data-active="{{ $item->is_active ? '1' : '0' }}">
                                        {{ $item->name }}{{ $item->is_active ? '' : ' (غیرفعال)' }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <form method="POST" action="{{ route('settings.lookups') }}" class="lookup-form-create">
                        @csrf
                        <input type="hidden" name="settings_tab" value="lookups">
                        <input type="hidden" name="group_key" value="{{ $groupKey }}">
                        <div class="accept-row accept-row-4">
                            <div>
                                <label>نام گزینه</label>
                                <input type="text" name="name" class="lookup-name" required placeholder="نام گزینه">
                            </div>
                            <div>
                                <label>ترتیب</label>
                                <input type="number" name="sort_order" class="lookup-sort" min="0" value="0">
                            </div>
                            <div>
                                @include('partials.toggle', [
                                    'name' => 'is_active',
                                    'label' => 'فعال در منوی پذیرش',
                                    'checked' => true,
                                ])
                            </div>
                        </div>
                        <div class="actions lookup-actions-create">
                            <button class="btn btn-primary" type="submit">افزودن به منو</button>
                        </div>
                    </form>

                    <form method="POST" action="#" class="lookup-form-edit hidden">
                        @csrf
                        <input type="hidden" name="settings_tab" value="lookups">
                        <input type="hidden" name="_method" value="PUT" class="lookup-method">
                        <div class="accept-row accept-row-4">
                            <div>
                                <label>نام گزینه</label>
                                <input type="text" name="name" class="lookup-name" required>
                            </div>
                            <div>
                                <label>ترتیب</label>
                                <input type="number" name="sort_order" class="lookup-sort" min="0" value="0">
                            </div>
                            <div>
                                @include('partials.toggle', [
                                    'name' => 'is_active',
                                    'label' => 'فعال در منوی پذیرش',
                                    'checked' => true,
                                ])
                            </div>
                        </div>
                        <div class="actions">
                            <button class="btn btn-primary lookup-save-btn" type="submit">ذخیره ویرایش</button>
                            <button class="btn btn-danger lookup-delete-btn" type="submit" data-confirm="حذف این گزینه؟">حذف</button>
                        </div>
                    </form>
                </div>
            @endforeach
        </div>

        <div class="ws-pane {{ $activeTab === 'faults' ? 'active' : '' }}" data-ws-pane="faults">
            <h2>انواع ایراد</h2>
            <p class="lead">از لیست انتخاب کنید، سپس ویرایش یا حذف کنید. برای مورد جدید «— جدید —» را بگذارید.</p>
            <div class="lookup-editor panel" data-simple-editor data-base-url="{{ url('settings/fault-types') }}">
                <div class="accept-row accept-row-4" style="margin-bottom:6px;">
                    <div style="grid-column:1/-1">
                        <label>انتخاب از منو</label>
                        <select class="simple-select">
                            <option value="">— جدید —</option>
                            @foreach($faultTypes as $item)
                                <option value="{{ $item->id }}"
                                        data-name="{{ $item->name }}"
                                        data-active="{{ $item->is_active ? '1' : '0' }}">
                                    {{ $item->name }}{{ $item->is_active ? '' : ' (غیرفعال)' }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <form method="POST" action="{{ route('settings.fault-types') }}" class="simple-form-create">
                    @csrf
                    <input type="hidden" name="settings_tab" value="faults">
                    <div class="accept-row accept-row-4">
                        <div>
                            <label>نام ایراد</label>
                            <input type="text" name="name" class="simple-name" required>
                        </div>
                        <div>
                            @include('partials.toggle', ['name' => 'is_active', 'label' => 'فعال', 'checked' => true])
                        </div>
                    </div>
                    <div class="actions simple-actions-create">
                        <button class="btn btn-primary" type="submit">افزودن</button>
                    </div>
                </form>
                <form method="POST" action="#" class="simple-form-edit hidden">
                    @csrf
                    <input type="hidden" name="settings_tab" value="faults">
                    <input type="hidden" name="_method" value="PUT" class="simple-method">
                    <div class="accept-row accept-row-4">
                        <div>
                            <label>نام ایراد</label>
                            <input type="text" name="name" class="simple-name" required>
                        </div>
                        <div>
                            @include('partials.toggle', ['name' => 'is_active', 'label' => 'فعال', 'checked' => true])
                        </div>
                    </div>
                    <div class="actions">
                        <button class="btn btn-primary simple-save-btn" type="submit">ذخیره ویرایش</button>
                        <button class="btn btn-danger simple-delete-btn" type="submit" data-confirm="حذف این نوع ایراد؟">حذف</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="ws-pane {{ $activeTab === 'referrals' ? 'active' : '' }}" data-ws-pane="referrals">
            <h2>نحوه آشنایی</h2>
            <p class="lead">از لیست انتخاب کنید، سپس ویرایش یا حذف کنید.</p>
            <div class="lookup-editor panel" data-simple-editor data-base-url="{{ url('settings/referral-sources') }}">
                <div class="accept-row accept-row-4" style="margin-bottom:6px;">
                    <div style="grid-column:1/-1">
                        <label>انتخاب از منو</label>
                        <select class="simple-select">
                            <option value="">— جدید —</option>
                            @foreach($referralSources as $item)
                                <option value="{{ $item->id }}"
                                        data-name="{{ $item->name }}"
                                        data-active="{{ $item->is_active ? '1' : '0' }}">
                                    {{ $item->name }}{{ $item->is_active ? '' : ' (غیرفعال)' }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <form method="POST" action="{{ route('settings.referral-sources') }}" class="simple-form-create">
                    @csrf
                    <input type="hidden" name="settings_tab" value="referrals">
                    <div class="accept-row accept-row-4">
                        <div>
                            <label>نام منبع</label>
                            <input type="text" name="name" class="simple-name" required>
                        </div>
                        <div>
                            @include('partials.toggle', ['name' => 'is_active', 'label' => 'فعال', 'checked' => true])
                        </div>
                    </div>
                    <div class="actions simple-actions-create">
                        <button class="btn btn-primary" type="submit">افزودن</button>
                    </div>
                </form>
                <form method="POST" action="#" class="simple-form-edit hidden">
                    @csrf
                    <input type="hidden" name="settings_tab" value="referrals">
                    <input type="hidden" name="_method" value="PUT" class="simple-method">
                    <div class="accept-row accept-row-4">
                        <div>
                            <label>نام منبع</label>
                            <input type="text" name="name" class="simple-name" required>
                        </div>
                        <div>
                            @include('partials.toggle', ['name' => 'is_active', 'label' => 'فعال', 'checked' => true])
                        </div>
                    </div>
                    <div class="actions">
                        <button class="btn btn-primary simple-save-btn" type="submit">ذخیره ویرایش</button>
                        <button class="btn btn-danger simple-delete-btn" type="submit" data-confirm="حذف این نحوه آشنایی؟">حذف</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="ws-pane {{ $activeTab === 'invoice' ? 'active' : '' }}" data-ws-pane="invoice">
            <h2>تنظیمات فاکتور و چاپ</h2>
            <p class="lead">اطلاعات سربرگ فاکتور، نمایش فیلدها، چاپ خودکار و شرایط تعمیرات را اینجا تنظیم کنید.</p>
            <form method="POST" action="{{ route('settings.invoice') }}">
                @csrf
                <input type="hidden" name="settings_tab" value="invoice">
                <div class="accept-row accept-row-2">
                    <div>
                        <label>نام فروشگاه / برند روی فاکتور</label>
                        <input type="text" name="invoice_shop_name" value="{{ old('invoice_shop_name', $invoice['shop_name']) }}">
                    </div>
                    <div>
                        <label>تلفن‌های تماس (نمایش روی فاکتور)</label>
                        <input type="text" name="invoice_phones" value="{{ old('invoice_phones', $invoice['phones']) }}" placeholder="021-... | 0912-...">
                    </div>
                    <div style="grid-column:1/-1">
                        <label>آدرس</label>
                        <input type="text" name="invoice_address" value="{{ old('invoice_address', $invoice['address']) }}">
                    </div>
                    <div style="grid-column:1/-1">
                        <label>اسم مجموعه در شبکه همکاران</label>
                        <input type="text" name="network_org_name" value="{{ old('network_org_name', $invoice['network_org_name'] ?? '') }}" placeholder="سرزمین هارد مرکز تخصصی بازیابی اطلاعات و تعمیرات هارد دیسک">
                        <div class="muted" style="font-size:11px;margin-top:4px;">همین نام در سرچ همکاران دیده می‌شود (سریال لایسنس مخفی است).</div>
                    </div>
                    <div style="grid-column:1/-1">
                        <label>آدرس مجموعه در شبکه همکاران</label>
                        <input type="text" name="network_address" value="{{ old('network_address', $invoice['network_address'] ?? '') }}" placeholder="اگر خالی باشد همان آدرس فاکتور استفاده می‌شود">
                    </div>
                    <div style="grid-column:1/-1">
                        <label>متن زیر عنوان / فوتر کوتاه</label>
                        <input type="text" name="invoice_footer" value="{{ old('invoice_footer', $invoice['footer']) }}">
                    </div>
                </div>

                <h3 style="margin-top:12px;">تنظیمات صفحه چاپ</h3>
                <div class="accept-row accept-row-4">
                    <div>
                        <label>اندازه فونت (pt)</label>
                        <input type="number" name="invoice_font_size" min="8" max="18" value="{{ old('invoice_font_size', $invoice['font_size'] ?? 11) }}">
                    </div>
                    <div>
                        <label>اندازه کاغذ</label>
                        <select name="invoice_page_size">
                            @foreach(['A4' => 'A4', 'A5' => 'A5', 'Letter' => 'Letter'] as $val => $label)
                                <option value="{{ $val }}" @selected(old('invoice_page_size', $invoice['page_size'] ?? 'A4') === $val)>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label>حاشیه چاپ (mm)</label>
                        <input type="number" name="invoice_margin_mm" min="4" max="25" value="{{ old('invoice_margin_mm', $invoice['margin_mm'] ?? 10) }}">
                    </div>
                    <div>
                        @include('partials.toggle', ['name' => 'invoice_show_logo', 'label' => 'نمایش لوگوی شرکت', 'checked' => $invoice['show_logo'] ?? true])
                    </div>
                </div>

                <h3 style="margin-top:12px;">نمایش فیلدها روی فاکتور</h3>
                <div class="toggle-grid">
                    @include('partials.toggle', ['name' => 'invoice_show_serial', 'label' => 'سریال دستگاه', 'checked' => $invoice['show_serial']])
                    @include('partials.toggle', ['name' => 'invoice_show_fault', 'label' => 'عیب اظهار مشتری', 'checked' => $invoice['show_fault']])
                    @include('partials.toggle', ['name' => 'invoice_show_accessories', 'label' => 'لوازم همراه', 'checked' => $invoice['show_accessories']])
                    @include('partials.toggle', ['name' => 'invoice_show_appearance', 'label' => 'وضعیت ظاهری', 'checked' => $invoice['show_appearance']])
                    @include('partials.toggle', ['name' => 'invoice_show_warranty', 'label' => 'گارانتی', 'checked' => $invoice['show_warranty']])
                    @include('partials.toggle', ['name' => 'invoice_show_technician', 'label' => 'تعمیرکار', 'checked' => $invoice['show_technician']])
                    @include('partials.toggle', ['name' => 'invoice_show_deposit', 'label' => 'بیعانه', 'checked' => $invoice['show_deposit']])
                    @include('partials.toggle', ['name' => 'invoice_show_estimated_cost', 'label' => 'هزینه تخمینی', 'checked' => $invoice['show_estimated_cost']])
                    @include('partials.toggle', ['name' => 'invoice_show_parts', 'label' => 'جدول قطعات', 'checked' => $invoice['show_parts']])
                    @include('partials.toggle', ['name' => 'invoice_show_payments', 'label' => 'جمع / پرداخت / مانده', 'checked' => $invoice['show_payments']])
                    @include('partials.toggle', ['name' => 'invoice_auto_print', 'label' => 'چاپ خودکار هنگام باز شدن فاکتور', 'checked' => $invoice['auto_print']])
                </div>

                <h3 style="margin-top:12px;">شرایط تعمیرات و قوانین</h3>
                <p class="lead">این متن پایین فاکتور چاپ می‌شود (شرایط پذیرش، گارانتی تعمیر، مسئولیت داده‌ها و …).</p>
                <div>
                    <label>متن شرایط</label>
                    <textarea name="invoice_terms" rows="8" placeholder="مثال: مسئولیت نگهداری اطلاعات با مشتری است. دستگاه پس از ۳۰ روز بلاتکلیف به انبار امانی منتقل می‌شود...">{{ old('invoice_terms', $invoice['terms']) }}</textarea>
                </div>

                <div class="actions">
                    <button class="btn btn-primary" type="submit">ذخیره تنظیمات فاکتور</button>
                </div>
            </form>
        </div>

        <div class="ws-pane {{ $activeTab === 'labels' ? 'active' : '' }}" data-ws-pane="labels">
            <h2>برچسب و بارکد</h2>
            <p class="lead">سایز رول، نوع بارکد، جای‌گذاری، حالت‌های چاپ و پرینتر مخصوص — برای قطعات انبار و دستگاه مشتری بعد از پذیرش.</p>

            <form method="POST" action="{{ route('settings.labels') }}" class="panel">
                @csrf
                <input type="hidden" name="settings_tab" value="labels">

                <h3 style="margin-top:0;">حالت چاپ پیش‌فرض (۳۵ حالت استاندارد)</h3>
                <div class="accept-row accept-row-2">
                    <div style="grid-column:1/-1">
                        <label>حالت چاپ</label>
                        <select name="label_print_mode">
                            @foreach($labelModes as $key => $mode)
                                <option value="{{ $key }}" @selected(old('label_print_mode', $labels['mode']) === $key)>{{ $mode['label'] }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <h3 style="margin-top:12px;">سایز رول / برگه</h3>
                <div class="accept-row accept-row-4">
                    <div>
                        <label>سایز برچسب</label>
                        <select name="label_size">
                            @foreach($labelSizes as $key => $size)
                                <option value="{{ $key }}" @selected(old('label_size', $labels['size_key']) === $key)>{{ $size['label'] }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label>عرض سفارشی (mm)</label>
                        <input type="number" name="label_custom_w" min="20" max="300" value="{{ old('label_custom_w', $labels['custom_w']) }}">
                    </div>
                    <div>
                        <label>ارتفاع سفارشی (mm)</label>
                        <input type="number" name="label_custom_h" min="15" max="300" value="{{ old('label_custom_h', $labels['custom_h']) }}">
                    </div>
                    <div>
                        <label>فاصله بین برچسب (mm)</label>
                        <input type="number" name="label_gap_mm" min="0" max="20" value="{{ old('label_gap_mm', $labels['gap_mm']) }}">
                    </div>
                    <div>
                        <label>حاشیه داخلی (mm)</label>
                        <input type="number" name="label_margin_mm" min="0" max="15" value="{{ old('label_margin_mm', $labels['margin_mm']) }}">
                    </div>
                    <div>
                        <label>اندازه فونت</label>
                        <input type="number" name="label_font_size" min="7" max="16" value="{{ old('label_font_size', $labels['font_size']) }}">
                    </div>
                    <div>
                        <label>تعداد پیش‌فرض چاپ</label>
                        <input type="number" name="label_copies_default" min="1" max="50" value="{{ old('label_copies_default', $labels['copies_default']) }}">
                    </div>
                </div>

                <h3 style="margin-top:12px;">نوع بارکد و چیدمان</h3>
                <div class="accept-row accept-row-4">
                    <div>
                        <label>نوع بارکد (سازگاری بارکدخوان)</label>
                        <select name="label_symbology">
                            @foreach($labelSymbologies as $key => $lab)
                                <option value="{{ $key }}" @selected(old('label_symbology', $labels['symbology']) === $key)>{{ $lab }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label>قالب محتوا</label>
                        <select name="label_layout">
                            @foreach($labelLayouts as $key => $lab)
                                <option value="{{ $key }}" @selected(old('label_layout', $labels['layout']) === $key)>{{ $lab }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label>مکان بارکد روی برچسب</label>
                        <select name="label_barcode_position">
                            @foreach($labelPositions as $key => $lab)
                                <option value="{{ $key }}" @selected(old('label_barcode_position', $labels['barcode_position']) === $key)>{{ $lab }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label>نام پرینتر مخصوص بارکد</label>
                        <input type="text" name="label_printer_name" value="{{ old('label_printer_name', $labels['printer_name']) }}" placeholder="مثلاً Xprinter XP-365B">
                    </div>
                </div>

                <div class="accept-row accept-row-3" style="margin-top:8px;">
                    @include('partials.toggle', ['name' => 'label_show_shop', 'label' => 'نمایش نام فروشگاه', 'checked' => (bool) old('label_show_shop', $labels['show_shop'])])
                    @include('partials.toggle', ['name' => 'label_show_text', 'label' => 'نمایش متن کنار بارکد', 'checked' => (bool) old('label_show_text', $labels['show_text'])])
                    @include('partials.toggle', ['name' => 'label_auto_print', 'label' => 'چاپ خودکار هنگام باز شدن برچسب', 'checked' => (bool) old('label_auto_print', $labels['auto_print'])])
                </div>

                <div class="actions" style="margin-top:10px;">
                    <button class="btn btn-primary" type="submit">ذخیره تنظیمات برچسب</button>
                    <a class="btn btn-secondary" href="{{ route('labels.preview') }}" target="_blank" rel="noopener">پیش‌نمایش / تست چاپ</a>
                </div>
            </form>
        </div>

        <div class="ws-pane {{ $activeTab === 'payments' ? 'active' : '' }}" data-ws-pane="payments">
            <h2>درگاه پرداخت و لینک بانک‌ها</h2>
            <p class="lead">زرین‌پال به‌صورت IPG واقعی فعال است. بانک‌ها بعد از گرفتن اطلاعات ترمینال اضافه می‌شوند.</p>
            <div class="panel" style="margin-bottom:10px;">
                <strong>وب‌سرویس مشتری:</strong>
                <div dir="ltr" style="margin-top:4px;"><a href="{{ $portalUrl }}" target="_blank">{{ $portalUrl }}</a></div>
            </div>
            <form method="POST" action="{{ route('settings.payments') }}">
                @csrf
                <input type="hidden" name="settings_tab" value="payments">
                <h3>زرین‌پال (IPG)</h3>
                <div class="pay-settings-grid">
                    <div class="pay-settings-card tone-amber">
                        <label for="zarinpal_merchant_id">Merchant ID</label>
                        <small>کد ۳۶ کاراکتری پنل زرین‌پال</small>
                        <input id="zarinpal_merchant_id" type="text" name="zarinpal_merchant_id"
                               value="{{ old('zarinpal_merchant_id', $zarinpal['merchant_id']) }}"
                               placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" dir="ltr">
                    </div>
                    <div class="pay-settings-card tone-amber">
                        <label for="zarinpal_currency">واحد مبلغ</label>
                        <small>IRT = تومان (پیشنهادی) · IRR = ریال</small>
                        <select id="zarinpal_currency" name="zarinpal_currency">
                            <option value="IRT" @selected(old('zarinpal_currency', $zarinpal['currency']) === 'IRT')>IRT — تومان</option>
                            <option value="IRR" @selected(old('zarinpal_currency', $zarinpal['currency']) === 'IRR')>IRR — ریال</option>
                        </select>
                    </div>
                </div>
                <div class="toggle-grid" style="margin-top:10px;">
                    @include('partials.toggle', ['name' => 'zarinpal_sandbox', 'label' => 'حالت تست (Sandbox)', 'checked' => $zarinpal['sandbox']])
                </div>
                <p class="lead" style="margin-top:8px;">
                    وضعیت:
                    @if($zarinpal['configured'])
                        <span class="pill pill-ok">آماده اتصال</span>
                    @else
                        <span class="pill pill-off">Merchant ID وارد نشده</span>
                    @endif
                </p>

                <h3 style="margin-top:16px;">لینک موقت بانک‌ها (تا اتصال IPG)</h3>
                <div class="pay-settings-grid">
                    @foreach($paymentGateways as $gw)
                        <div class="pay-settings-card tone-{{ $gw['tone'] }}">
                            <label for="pay-{{ $gw['key'] }}">{{ $gw['label'] }}</label>
                            <small>{{ $gw['hint'] }}</small>
                            <input id="pay-{{ $gw['key'] }}"
                                   type="url"
                                   name="pay_link_{{ $gw['key'] }}"
                                   value="{{ old('pay_link_'.$gw['key'], $gw['url']) }}"
                                   placeholder="https://..."
                                   dir="ltr">
                        </div>
                    @endforeach
                </div>
                <div class="toggle-grid" style="margin-top:10px;">
                    @include('partials.toggle', ['name' => 'pay_links_show_reception', 'label' => 'نمایش لینک بانک در صفحه قبض', 'checked' => $paymentLinksShow['reception']])
                    @include('partials.toggle', ['name' => 'pay_links_show_invoice', 'label' => 'نمایش لینک بانک روی فاکتور چاپ', 'checked' => $paymentLinksShow['invoice']])
                    @include('partials.toggle', ['name' => 'portal_otp_debug', 'label' => 'نمایش کد OTP کارتابل مشتری (فقط تست)', 'checked' => $paymentLinksShow['otp_debug']])
                </div>

                <h3 style="margin-top:18px;">واریز کارت‌به‌کارت (پرتال مشتری)</h3>
                <p class="lead">شماره کارت شرکت برای نمایش در کارتابل مشتری. فیش‌ها فقط توسط مدیر و حسابدار تأیید می‌شوند.</p>
                <div class="toggle-grid" style="margin-top:8px;">
                    @include('partials.toggle', ['name' => 'bank_transfer_enabled', 'label' => 'فعال‌سازی نمایش کارت و آپلود فیش در پرتال', 'checked' => $bankTransfer['enabled']])
                </div>
                <div class="pay-settings-grid" style="margin-top:10px;">
                    <div class="pay-settings-card tone-amber">
                        <label for="bank_card_number">شماره کارت</label>
                        <small>۱۶ رقم کارت مقصد شرکت</small>
                        <input id="bank_card_number" type="text" name="bank_card_number"
                               value="{{ old('bank_card_number', $bankTransfer['card_number']) }}"
                               placeholder="6037...." dir="ltr" maxlength="32">
                    </div>
                    <div class="pay-settings-card tone-amber">
                        <label for="bank_card_holder">نام صاحب کارت</label>
                        <small>همان‌طور که روی کارت/حساب است</small>
                        <input id="bank_card_holder" type="text" name="bank_card_holder"
                               value="{{ old('bank_card_holder', $bankTransfer['card_holder']) }}">
                    </div>
                    <div class="pay-settings-card">
                        <label for="bank_name">نام بانک</label>
                        <input id="bank_name" type="text" name="bank_name"
                               value="{{ old('bank_name', $bankTransfer['bank_name']) }}" placeholder="مثلاً ملت">
                    </div>
                    <div class="pay-settings-card">
                        <label for="bank_iban">شبا (اختیاری)</label>
                        <input id="bank_iban" type="text" name="bank_iban"
                               value="{{ old('bank_iban', $bankTransfer['iban']) }}" placeholder="IR..." dir="ltr">
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <label for="bank_transfer_instructions">راهنمای مشتری</label>
                    <textarea id="bank_transfer_instructions" name="bank_transfer_instructions" rows="3"
                              placeholder="مثلاً بعد از واریز، تصویر فیش را از همین صفحه ارسال کنید.">{{ old('bank_transfer_instructions', $bankTransfer['instructions']) }}</textarea>
                </div>

                <div class="actions">
                    <button class="btn btn-primary" type="submit">ذخیره تنظیمات پرداخت</button>
                </div>
            </form>
        </div>

        <div class="ws-pane {{ $activeTab === 'sms' ? 'active' : '' }}" data-ws-pane="sms">
            <h2>پنل نیازپرداز</h2>
            <form method="POST" action="{{ route('settings.sms') }}">
                @csrf
                <input type="hidden" name="settings_tab" value="sms">
                <div class="form-grid" style="grid-template-columns:1fr 1fr;">
                    <div><label>نام کاربری پنل</label><input type="text" name="niazpardaz_username" value="{{ $sms['username'] }}"></div>
                    <div><label>رمز پنل</label><input type="password" name="niazpardaz_password" value="{{ $sms['password'] }}"></div>
                    <div><label>API Key (اختیاری)</label><input type="text" name="niazpardaz_api_key" value="{{ $sms['api_key'] }}"></div>
                    <div><label>شماره فرستنده</label><input type="text" name="niazpardaz_from" value="{{ $sms['from'] }}" placeholder="1000..."></div>
                </div>
                <div class="actions"><button class="btn btn-primary" type="submit">ذخیره تنظیمات پیامک</button></div>
            </form>

            <div class="panel" style="margin-top:10px;">
                <h3>تست پنل پیامک</h3>
                <p class="lead">پس از ذخیره تنظیمات، یک پیامک تست به شماره دلخواه بفرستید تا اتصال پنل را بررسی کنید.</p>
                <form method="POST" action="{{ route('settings.sms.test') }}">
                    @csrf
                    <input type="hidden" name="settings_tab" value="sms">
                    <div class="accept-row accept-row-3">
                        <div>
                            <label>شماره موبایل گیرنده تست</label>
                            <input type="text" name="test_phone" value="{{ old('test_phone') }}" placeholder="09xxxxxxxxx" required>
                        </div>
                        <div style="display:flex;align-items:end;">
                            <button class="btn btn-secondary" type="submit">ارسال پیامک تست</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="ws-pane {{ $activeTab === 'backup' ? 'active' : '' }}" data-ws-pane="backup" id="backup">
            <h2>بکاپ خودکار دیتابیس</h2>
            <p class="lead">
                بکاپ کامل سیستم (تمام جداول قبض، مشتری، کارمند، تنظیمات) به‌صورت خودکار طبق زمان‌بندی ساخته می‌شود تا سیستم قبض کند نشود و داده امن بماند.
            </p>

            <div class="panel" style="margin-bottom:12px;padding:12px;border:1px solid #c5d4e8;background:linear-gradient(180deg,#f7fbff,#eef4fb);">
                <h3 style="margin:0 0 6px;">بکاپ کامل خودکار</h3>
                <p class="muted" style="margin:0 0 10px;">
                    پیشنهاد: «فعال» + محدوده «کامل سیستم» + بازه «هر روز».
                    کرون هاست را هر ساعت صدا بزنید؛ سیستم خودش در ساعت تعیین‌شده بکاپ کامل می‌گیرد.
                </p>
                <div class="accept-row accept-row-3" style="align-items:end;margin-bottom:8px;">
                    <div>
                        <label>وضعیت فعلی</label>
                        <div>
                            @if($backup['enabled'])
                                <span class="pill pill-ok">خودکار روشن — {{ $backupScopes[$backup['scope']] ?? $backup['scope'] }} / {{ $backupIntervals[$backup['interval']] ?? $backup['interval'] }}</span>
                            @else
                                <span class="pill pill-off">خودکار خاموش است</span>
                            @endif
                        </div>
                    </div>
                    <div>
                        <label>آخرین فایل</label>
                        <div dir="ltr" style="text-align:left;font-size:12px;">{{ $backup['last_file'] ?: '—' }}</div>
                    </div>
                    <div class="actions" style="margin:0;">
                        <form method="POST" action="{{ route('settings.backup.run-now') }}" data-confirm="بکاپ کامل دیتابیس الآن ساخته شود؟">
                            @csrf
                            <button class="btn btn-primary" type="submit">اجرای فوری بکاپ کامل</button>
                        </form>
                    </div>
                </div>
            </div>

            @if(auth()->user()->canAccess('system.tools'))
            <div class="split-2" style="gap:10px;margin-bottom:12px;">
                <div class="panel" style="padding:10px;">
                    <h3 style="margin:0 0 6px;">ذخیره بکاپ روی کامپیوتر</h3>
                    <p class="muted" style="margin:0 0 8px;">
                        برای انتقال به هاست جدید، «کامل سیستم» را انتخاب کنید تا مشتری، قبض، کارمند، منوها و تنظیمات برگردند.
                    </p>
                    <form method="POST" action="{{ route('system-tools.run') }}">
                        @csrf
                        <input type="hidden" name="settings_tab" value="backup">
                        <input type="hidden" name="action" value="backup_save_pc">
                        <div class="accept-row accept-row-2" style="align-items:end;">
                            <div>
                                <label>نوع بکاپ</label>
                                <select name="scope">
                                    <option value="full" selected>کامل سیستم (پیشنهادی برای ریستور/هاست جدید)</option>
                                    <option value="accounting">فقط حسابداری و مالی</option>
                                </select>
                            </div>
                            <div class="actions" style="margin:0;">
                                <button class="btn btn-primary" type="submit">ساخت و ذخیره روی کامپیوتر</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="panel" style="padding:10px;">
                    <h3 style="margin:0 0 6px;">ریستور بکاپ از کامپیوتر</h3>
                    <p class="muted" style="margin:0 0 8px;">فایل `.sql` / `.sql.gz` کامل را از کامپیوتر انتخاب کنید تا همه داده‌ها برگردند.</p>
                    <form method="POST" action="{{ route('system-tools.run') }}" enctype="multipart/form-data"
                          data-confirm="ریستور از فایل کامپیوتر؟ جداول داخل فایل جایگزین می‌شوند.">
                        @csrf
                        <input type="hidden" name="settings_tab" value="backup">
                        <input type="hidden" name="action" value="backup_restore_upload">
                        <div style="margin-bottom:8px;">
                            <input type="file" name="backup_file" accept=".sql,.gz,application/gzip" required>
                        </div>
                        @include('partials.toggle', [
                            'name' => 'confirm_restore',
                            'label' => 'تأیید ریستور از این فایل',
                            'checked' => false,
                        ])
                        <div class="actions" style="margin-top:8px;">
                            <button class="btn btn-danger" type="submit">ریستور از کامپیوتر</button>
                            <a class="btn btn-ghost" href="{{ route('system-tools.index') }}">ابزار کامل بکاپ</a>
                        </div>
                    </form>
                </div>
            </div>
            @endif

            <form method="POST" action="{{ route('settings.backup') }}">
                @csrf
                <input type="hidden" name="settings_tab" value="backup">
                <div class="panel" style="margin-bottom:10px;">
                    <h3 style="margin-top:0;">زمان‌بندی</h3>
                    <div class="accept-row accept-row-4" style="align-items:end;">
                        <div>
                            @include('partials.toggle', [
                                'name' => 'enabled',
                                'label' => 'بکاپ خودکار فعال باشد',
                                'checked' => $backup['enabled'],
                            ])
                        </div>
                        <div>
                            <label>محدوده بکاپ</label>
                            <select name="scope">
                                @foreach($backupScopes as $key => $label)
                                    <option value="{{ $key }}" @selected($backup['scope'] === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label>بازه تکرار</label>
                            <select name="interval">
                                @foreach($backupIntervals as $key => $label)
                                    <option value="{{ $key }}" @selected($backup['interval'] === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label>روز هفته (برای هفتگی)</label>
                            <select name="weekday">
                                @foreach($backupWeekdays as $key => $label)
                                    <option value="{{ $key }}" @selected((int)$backup['weekday'] === (int)$key)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label>ساعت اجرا (۰–۲۳ تهران)</label>
                            <input type="number" name="hour" min="0" max="23" value="{{ $backup['hour'] }}">
                        </div>
                        <div>
                            <label>نگهداری محلی (تعداد فایل)</label>
                            <input type="number" name="keep_local" min="1" max="60" value="{{ $backup['keep_local'] }}">
                        </div>
                    </div>
                </div>

                <div class="panel" style="margin-bottom:10px;" id="backup-clouds">
                    <h3 style="margin-top:0;">کلودها (Google / Microsoft / MEGA)</h3>
                    <p class="muted" style="margin-top:0;">
                        بعد از اتصال، بکاپ‌های خودکار (طبق زمان‌بندی) و دستی به کلودهای فعال آپلود می‌شوند.
                        ابتدا مشخصات را ذخیره کنید، سپس دکمه اتصال را بزنید.
                    </p>

                    <div class="split-2" style="gap:12px;">
                        {{-- Google Drive --}}
                        <div class="panel" style="margin:0;padding:10px;border:1px solid #d9dee7;">
                            <h3 style="margin:0 0 6px;">{{ $backupCloudLabels['google'] }}</h3>
                            <p class="muted" style="margin:0 0 8px;font-size:12px;">
                                در Google Cloud Console یک OAuth Client از نوع Web بسازید و Redirect URI زیر را ثبت کنید.
                            </p>
                            <div style="margin-bottom:8px;">
                                <label>Redirect URI</label>
                                <input type="text" readonly dir="ltr" style="text-align:left;font-size:11px;" value="{{ $googleRedirectUri }}">
                            </div>
                            <div class="accept-row accept-row-2">
                                <div>
                                    <label>Client ID</label>
                                    <input type="text" name="clouds[google][client_id]" value="{{ $backup['clouds']['google']['client_id'] }}" dir="ltr" style="text-align:left;" autocomplete="off">
                                </div>
                                <div>
                                    <label>Client Secret</label>
                                    <input type="password" name="clouds[google][client_secret]" value="" placeholder="{{ $backup['clouds']['google']['client_secret'] ? '•••••• (خالی = بدون تغییر)' : 'Secret' }}" dir="ltr" style="text-align:left;" autocomplete="new-password">
                                </div>
                                <div>
                                    <label>پوشه مقصد</label>
                                    <input type="text" name="clouds[google][folder]" value="{{ $backup['clouds']['google']['folder'] }}" dir="ltr" style="text-align:left;">
                                </div>
                                <div>
                                    @include('partials.toggle', [
                                        'name' => 'clouds[google][enabled]',
                                        'label' => 'آپلود خودکار به گوگل',
                                        'checked' => $backup['clouds']['google']['enabled'],
                                    ])
                                </div>
                            </div>
                            <p class="muted" style="margin:6px 0;">
                                وضعیت:
                                @if($backup['clouds']['google']['connected'])
                                    <span class="pill pill-ok">متصل{{ $backup['clouds']['google']['account_email'] ? ' — '.$backup['clouds']['google']['account_email'] : '' }}</span>
                                @else
                                    <span class="pill pill-off">متصل نشده</span>
                                @endif
                            </p>
                            <div class="actions" style="margin:0;">
                                <a class="btn btn-primary" href="{{ route('settings.backup.cloud.connect', 'google') }}">اتصال به گوگل</a>
                                <button class="btn btn-secondary" form="backup-cloud-test-google" type="submit">تست</button>
                                <button class="btn btn-ghost" form="backup-cloud-disconnect-google" type="submit">قطع اتصال</button>
                            </div>
                        </div>

                        {{-- OneDrive --}}
                        <div class="panel" style="margin:0;padding:10px;border:1px solid #d9dee7;">
                            <h3 style="margin:0 0 6px;">{{ $backupCloudLabels['onedrive'] }}</h3>
                            <p class="muted" style="margin:0 0 8px;font-size:12px;">
                                در Azure Portal یک App Registration بسازید و Redirect URI زیر را به‌عنوان Web ثبت کنید.
                            </p>
                            <div style="margin-bottom:8px;">
                                <label>Redirect URI</label>
                                <input type="text" readonly dir="ltr" style="text-align:left;font-size:11px;" value="{{ $onedriveRedirectUri }}">
                            </div>
                            <div class="accept-row accept-row-2">
                                <div>
                                    <label>Application (client) ID</label>
                                    <input type="text" name="clouds[onedrive][client_id]" value="{{ $backup['clouds']['onedrive']['client_id'] }}" dir="ltr" style="text-align:left;" autocomplete="off">
                                </div>
                                <div>
                                    <label>Client Secret</label>
                                    <input type="password" name="clouds[onedrive][client_secret]" value="" placeholder="{{ $backup['clouds']['onedrive']['client_secret'] ? '•••••• (خالی = بدون تغییر)' : 'Secret' }}" dir="ltr" style="text-align:left;" autocomplete="new-password">
                                </div>
                                <div>
                                    <label>پوشه مقصد</label>
                                    <input type="text" name="clouds[onedrive][folder]" value="{{ $backup['clouds']['onedrive']['folder'] }}" dir="ltr" style="text-align:left;">
                                </div>
                                <div>
                                    @include('partials.toggle', [
                                        'name' => 'clouds[onedrive][enabled]',
                                        'label' => 'آپلود خودکار به OneDrive',
                                        'checked' => $backup['clouds']['onedrive']['enabled'],
                                    ])
                                </div>
                            </div>
                            <p class="muted" style="margin:6px 0;">
                                وضعیت:
                                @if($backup['clouds']['onedrive']['connected'])
                                    <span class="pill pill-ok">متصل{{ $backup['clouds']['onedrive']['account_email'] ? ' — '.$backup['clouds']['onedrive']['account_email'] : '' }}</span>
                                @else
                                    <span class="pill pill-off">متصل نشده</span>
                                @endif
                            </p>
                            <div class="actions" style="margin:0;">
                                <a class="btn btn-primary" href="{{ route('settings.backup.cloud.connect', 'onedrive') }}">اتصال به مایکروسافت</a>
                                <button class="btn btn-secondary" form="backup-cloud-test-onedrive" type="submit">تست</button>
                                <button class="btn btn-ghost" form="backup-cloud-disconnect-onedrive" type="submit">قطع اتصال</button>
                            </div>
                        </div>
                    </div>

                    {{-- MEGA --}}
                    <div class="panel" style="margin-top:12px;padding:10px;border:1px solid #d9dee7;">
                        <h3 style="margin:0 0 6px;">{{ $backupCloudLabels['mega'] }}</h3>
                        <p class="muted" style="margin:0 0 8px;font-size:12px;">با ایمیل و رمز حساب MEGA وصل شوید. برای هاست اشتراکی افزونه GMP توصیه می‌شود.</p>
                        <div class="accept-row accept-row-4" style="align-items:end;">
                            <div>
                                <label>ایمیل MEGA</label>
                                <input type="email" name="clouds[mega][email]" value="{{ $backup['clouds']['mega']['email'] }}" dir="ltr" style="text-align:left;" autocomplete="off">
                            </div>
                            <div>
                                <label>رمز عبور</label>
                                <input type="password" name="clouds[mega][password]" value="" placeholder="{{ $backup['clouds']['mega']['password'] ? '•••••• (خالی = بدون تغییر)' : 'رمز MEGA' }}" dir="ltr" style="text-align:left;" autocomplete="new-password">
                            </div>
                            <div>
                                <label>پوشه مقصد</label>
                                <input type="text" name="clouds[mega][folder]" value="{{ $backup['clouds']['mega']['folder'] }}" dir="ltr" style="text-align:left;">
                            </div>
                            <div>
                                @include('partials.toggle', [
                                    'name' => 'clouds[mega][enabled]',
                                    'label' => 'آپلود خودکار به MEGA',
                                    'checked' => $backup['clouds']['mega']['enabled'],
                                ])
                            </div>
                        </div>
                        <p class="muted" style="margin:6px 0;">
                            وضعیت:
                            @if($backup['clouds']['mega']['connected'])
                                <span class="pill pill-ok">متصل{{ $backup['clouds']['mega']['account_email'] ? ' — '.$backup['clouds']['mega']['account_email'] : '' }}</span>
                            @else
                                <span class="pill pill-off">متصل نشده</span>
                            @endif
                        </p>
                        <div class="actions" style="margin:0;">
                            <a class="btn btn-primary" href="{{ route('settings.backup.cloud.connect', 'mega') }}">تست و اتصال MEGA</a>
                            <button class="btn btn-secondary" form="backup-cloud-test-mega" type="submit">تست دوباره</button>
                            <button class="btn btn-ghost" form="backup-cloud-disconnect-mega" type="submit">قطع اتصال</button>
                        </div>
                    </div>
                </div>

                <div class="panel" style="margin-bottom:10px;">
                    <h3 style="margin-top:0;">هاست ریموت (FTP)</h3>
                    <p class="muted" style="margin-top:0;">آدرس هاستی که بکاپ باید هر هفته آنجا آپلود شود — مثلاً بکاپ‌سرور یا فضای FTP دیگر.</p>
                    <div class="accept-row accept-row-4" style="align-items:end;">
                        <div>
                            @include('partials.toggle', [
                                'name' => 'remote_enabled',
                                'label' => 'آپلود خودکار به هاست',
                                'checked' => $backup['remote_enabled'],
                            ])
                        </div>
                        <div>
                            <label>پروتکل</label>
                            <select name="remote_protocol">
                                @foreach($backupProtocols as $key => $label)
                                    <option value="{{ $key }}" @selected($backup['remote_protocol'] === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label>آدرس هاست</label>
                            <input type="text" name="remote_host" value="{{ $backup['remote_host'] }}" placeholder="ftp.example.com" dir="ltr" style="text-align:left;">
                        </div>
                        <div>
                            <label>پورت</label>
                            <input type="number" name="remote_port" min="1" max="65535" value="{{ $backup['remote_port'] }}">
                        </div>
                        <div>
                            <label>نام کاربری</label>
                            <input type="text" name="remote_user" value="{{ $backup['remote_user'] }}" dir="ltr" style="text-align:left;" autocomplete="off">
                        </div>
                        <div>
                            <label>رمز عبور</label>
                            <input type="password" name="remote_password" value="" placeholder="{{ $backup['remote_password'] ? '•••••• (خالی = بدون تغییر)' : 'رمز FTP' }}" dir="ltr" style="text-align:left;" autocomplete="new-password">
                        </div>
                        <div style="grid-column:1/-1">
                            <label>مسیر پوشه روی هاست</label>
                            <input type="text" name="remote_path" value="{{ $backup['remote_path'] }}" placeholder="/backups" dir="ltr" style="text-align:left;">
                        </div>
                    </div>
                </div>

                <div class="panel" style="margin-bottom:10px;">
                    <h3 style="margin-top:0;">کرون هاست (cPanel)</h3>
                    <p class="muted" style="margin:0 0 6px;">در cPanel → Cron Jobs این آدرس را هر ساعت صدا بزنید. سیستم خودش تشخیص می‌دهد آیا وقت بکاپ هفتگی/روزانه رسیده یا نه.</p>
                    <div class="accept-row accept-row-2">
                        <div style="grid-column:1/-1">
                            <label>دستور پیشنهادی Cron</label>
                            <input type="text" readonly dir="ltr" style="text-align:left;font-family:monospace;font-size:11px;"
                                   value="curl -fsS '{{ $backupCronUrl }}'">
                        </div>
                        <div>
                            <label>آخرین اجرا</label>
                            <div>{{ $backup['last_run_at'] ? jalali_like($backup['last_run_at']) : '—' }}</div>
                        </div>
                        <div>
                            <label>آخرین نتیجه</label>
                            <div>{{ $backup['last_message'] ?: '—' }}</div>
                        </div>
                    </div>
                    <p class="hint" style="margin-top:6px;">اجرای اجباری تست: <code dir="ltr">{{ $backupCronUrl }}&amp;force=1</code></p>
                </div>

                <div class="actions">
                    <button class="btn btn-primary" type="submit">ذخیره تنظیمات بکاپ</button>
                    <button class="btn btn-secondary" form="backup-upload-clouds-now" type="submit">ساخت بکاپ و آپلود به کلودها الآن</button>
                    <a class="btn btn-ghost" href="{{ route('system-tools.index') }}">ابزار بکاپ / ریستور</a>
                </div>
            </form>

            {{-- Forms خارج از فرم اصلی (HTML فرم تو در تو مجاز نیست) --}}
            <form id="backup-cloud-test-google" method="POST" action="{{ route('settings.backup.cloud.test', 'google') }}" class="hidden">@csrf</form>
            <form id="backup-cloud-disconnect-google" method="POST" action="{{ route('settings.backup.cloud.disconnect', 'google') }}" class="hidden">@csrf</form>
            <form id="backup-cloud-test-onedrive" method="POST" action="{{ route('settings.backup.cloud.test', 'onedrive') }}" class="hidden">@csrf</form>
            <form id="backup-cloud-disconnect-onedrive" method="POST" action="{{ route('settings.backup.cloud.disconnect', 'onedrive') }}" class="hidden">@csrf</form>
            <form id="backup-cloud-test-mega" method="POST" action="{{ route('settings.backup.cloud.test', 'mega') }}" class="hidden">@csrf</form>
            <form id="backup-cloud-disconnect-mega" method="POST" action="{{ route('settings.backup.cloud.disconnect', 'mega') }}" class="hidden">@csrf</form>
            @if(auth()->user()->canAccess('system.tools'))
            <form id="backup-upload-clouds-now" method="POST" action="{{ route('system-tools.run') }}" class="hidden">
                @csrf
                <input type="hidden" name="settings_tab" value="backup">
                <input type="hidden" name="action" value="backup_upload_clouds">
            </form>
            @endif
        </div>

        <div class="ws-pane {{ ($activeTab ?? '') === 'seo' ? 'active' : '' }}" data-ws-pane="seo">
            <h2>سئو و رتبه گوگل</h2>
            <p class="lead">موتور سئوی داخلی: عنوان و توضیح متا، Open Graph، اسکیما JSON-LD، robots.txt، sitemap.xml و صفحهٔ دامنهٔ اصلی برای ایندکس بهتر در گوگل.</p>

            <div class="panel" style="margin-bottom:12px;background:#f3f7ff;border-color:#b7c8e8;">
                <strong>لینک‌های زنده</strong>
                <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:10px 16px;font-size:13px;">
                    <a href="{{ $seoRobotsUrl }}" target="_blank" rel="noopener" dir="ltr">{{ $seoRobotsUrl }}</a>
                    <a href="{{ $seoSitemapUrl }}" target="_blank" rel="noopener" dir="ltr">{{ $seoSitemapUrl }}</a>
                </div>
                <p class="muted" style="margin:8px 0 0;font-size:12px;">بعد از ذخیره، همین آدرس‌ها را در Google Search Console به‌عنوان Sitemap ثبت کنید.</p>
            </div>

            <form method="POST" action="{{ route('settings.seo') }}" enctype="multipart/form-data" class="panel">
                @csrf
                <input type="hidden" name="settings_tab" value="seo">

                <h3 style="margin:0 0 10px;">فعال‌سازی و ایندکس</h3>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
                    <input type="checkbox" name="enabled" value="1" @checked(old('enabled', $seo['enabled'] ?? '1') === '1')>
                    موتور SEO فعال باشد
                </label>
                <div class="accept-row accept-row-3">
                    <label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="index_gate" value="1" @checked(old('index_gate', $seo['index_gate'] ?? '1') === '1')> ایندکس صفحه اصلی (/)</label>
                    <label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="index_login" value="1" @checked(old('index_login', $seo['index_login'] ?? '1') === '1')> ایندکس ورود کارمند</label>
                    <label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="index_cartable" value="1" @checked(old('index_cartable', $seo['index_cartable'] ?? '1') === '1')> ایندکس ورود کارتابل</label>
                </div>
                <p class="muted" style="margin:6px 0 14px;font-size:12px;">صفحات داخلی پنل (داشبورد، قبض، گزارش و …) همیشه noindex می‌مانند تا گوگل فقط برند شما را ببیند.</p>

                <h3 style="margin:0 0 10px;">عنوان و توضیح</h3>
                <div class="accept-row accept-row-2">
                    <div>
                        <label>عنوان سایت (برند در گوگل)</label>
                        <input type="text" name="site_title" value="{{ old('site_title', $seo['site_title'] ?? '') }}" maxlength="120" placeholder="مثلاً کانون بازیابی اطلاعات دکتر هارد">
                    </div>
                    <div>
                        <label>پسوند عنوان</label>
                        <input type="text" name="title_suffix" value="{{ old('title_suffix', $seo['title_suffix'] ?? '') }}" maxlength="120" placeholder="ورود به سامانه">
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <label>توضیح متا (Description) — حدود ۱۵۰ تا ۱۶۰ کاراکتر</label>
                    <textarea name="description" rows="3" maxlength="320">{{ old('description', $seo['description'] ?? '') }}</textarea>
                </div>
                <div style="margin-top:10px;">
                    <label>کلمات کلیدی (با ویرگول)</label>
                    <input type="text" name="keywords" value="{{ old('keywords', $seo['keywords'] ?? '') }}" maxlength="500" placeholder="بازیابی اطلاعات، تعمیر هارد، قبض تعمیرگاه">
                </div>
                <div class="accept-row accept-row-2" style="margin-top:10px;">
                    <div>
                        <label>آدرس پایهٔ عمومی (Canonical)</label>
                        <input type="url" name="canonical_base" value="{{ old('canonical_base', $seo['canonical_base'] ?? '') }}" dir="ltr" style="text-align:left;" placeholder="https://hddsoftware.ir">
                        <p class="muted" style="margin:4px 0 0;font-size:11px;">اگر دامنهٔ اصلی جدا از ساب‌دامین پنل است، همین را بگذارید (بدون اسلش آخر).</p>
                    </div>
                    <div>
                        <label>زبان / لوکیل</label>
                        <input type="text" name="locale" value="{{ old('locale', $seo['locale'] ?? 'fa_IR') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>
                <div class="accept-row accept-row-2" style="margin-top:10px;">
                    <div>
                        <label>robots صفحات عمومی</label>
                        <input type="text" name="robots_public" value="{{ old('robots_public', $seo['robots_public'] ?? 'index,follow') }}" dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>robots صفحات داخلی</label>
                        <input type="text" name="robots_private" value="{{ old('robots_private', $seo['robots_private'] ?? 'noindex,nofollow') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>

                <h3 style="margin:18px 0 10px;">Open Graph / شبکه‌های اجتماعی</h3>
                <div class="accept-row accept-row-2">
                    <div>
                        <label>عنوان OG</label>
                        <input type="text" name="og_title" value="{{ old('og_title', $seo['og_title'] ?? '') }}" maxlength="120">
                    </div>
                    <div>
                        <label>نوع کارت توییتر</label>
                        <select name="twitter_card">
                            <option value="summary_large_image" @selected(old('twitter_card', $seo['twitter_card'] ?? '') === 'summary_large_image')>summary_large_image</option>
                            <option value="summary" @selected(old('twitter_card', $seo['twitter_card'] ?? '') === 'summary')>summary</option>
                        </select>
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <label>توضیح OG</label>
                    <textarea name="og_description" rows="2" maxlength="320">{{ old('og_description', $seo['og_description'] ?? '') }}</textarea>
                </div>
                <div class="accept-row accept-row-2" style="margin-top:10px;">
                    <div>
                        <label>آدرس تصویر OG فعلی</label>
                        <input type="url" name="og_image_url_display" value="{{ $seo['og_image'] ?? '' }}" readonly dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>آپلود تصویر OG جدید</label>
                        <input type="file" name="og_image_file" accept="image/*">
                    </div>
                </div>

                <h3 style="margin:18px 0 10px;">تأیید Search Console</h3>
                <div class="accept-row accept-row-2">
                    <div>
                        <label>کد تأیید گوگل (google-site-verification)</label>
                        <input type="text" name="gsc_verification" value="{{ old('gsc_verification', $seo['gsc_verification'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>کد تأیید بینگ (msvalidate.01)</label>
                        <input type="text" name="bing_verification" value="{{ old('bing_verification', $seo['bing_verification'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>

                <h3 style="margin:18px 0 10px;">اسکیما کسب‌وکار (JSON-LD)</h3>
                <div class="accept-row accept-row-2">
                    <div>
                        <label>نوع کسب‌وکار (schema.org)</label>
                        <input type="text" name="business_type" value="{{ old('business_type', $seo['business_type'] ?? 'LocalBusiness') }}" dir="ltr" style="text-align:left;" placeholder="LocalBusiness / ComputerStore">
                    </div>
                    <div>
                        <label>نام کسب‌وکار</label>
                        <input type="text" name="business_name" value="{{ old('business_name', $seo['business_name'] ?? '') }}">
                    </div>
                </div>
                <div class="accept-row accept-row-2" style="margin-top:10px;">
                    <div>
                        <label>نام جایگزین</label>
                        <input type="text" name="business_alt_name" value="{{ old('business_alt_name', $seo['business_alt_name'] ?? '') }}" placeholder="اگر برند دیگری هم دارید">
                    </div>
                    <div>
                        <label>بازه قیمت</label>
                        <input type="text" name="price_range" value="{{ old('price_range', $seo['price_range'] ?? '$$') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>
                <div class="accept-row accept-row-3" style="margin-top:10px;">
                    <div>
                        <label>تلفن</label>
                        <input type="text" name="business_phone" value="{{ old('business_phone', $seo['business_phone'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>موبایل</label>
                        <input type="text" name="business_mobile" value="{{ old('business_mobile', $seo['business_mobile'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>ایمیل</label>
                        <input type="email" name="business_email" value="{{ old('business_email', $seo['business_email'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <label>آدرس</label>
                    <input type="text" name="business_address" value="{{ old('business_address', $seo['business_address'] ?? '') }}">
                </div>
                <div class="accept-row accept-row-4" style="margin-top:10px;">
                    <div>
                        <label>شهر</label>
                        <input type="text" name="business_city" value="{{ old('business_city', $seo['business_city'] ?? '') }}">
                    </div>
                    <div>
                        <label>استان</label>
                        <input type="text" name="business_region" value="{{ old('business_region', $seo['business_region'] ?? '') }}">
                    </div>
                    <div>
                        <label>کد پستی</label>
                        <input type="text" name="business_postal" value="{{ old('business_postal', $seo['business_postal'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>کشور</label>
                        <input type="text" name="business_country" value="{{ old('business_country', $seo['business_country'] ?? 'IR') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>
                <div class="accept-row accept-row-2" style="margin-top:10px;">
                    <div>
                        <label>عرض جغرافیایی</label>
                        <input type="text" name="geo_lat" value="{{ old('geo_lat', $seo['geo_lat'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                    <div>
                        <label>طول جغرافیایی</label>
                        <input type="text" name="geo_lng" value="{{ old('geo_lng', $seo['geo_lng'] ?? '') }}" dir="ltr" style="text-align:left;">
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <label>لینک‌های شبکه‌های اجتماعی (هر خط یا با ویرگول)</label>
                    <textarea name="same_as" rows="3" placeholder="https://instagram.com/...">{{ old('same_as', $seo['same_as'] ?? '') }}</textarea>
                </div>
                <div style="margin-top:10px;">
                    <label>ساعات کاری (schema openingHours — هر خط یک مقدار)</label>
                    <textarea name="opening_hours" rows="3" placeholder="Mo-Sa 09:00-20:00" dir="ltr" style="text-align:left;">{{ old('opening_hours', $seo['opening_hours'] ?? '') }}</textarea>
                </div>
                <div style="margin-top:10px;">
                    <label>قوانین اضافه robots.txt</label>
                    <textarea name="robots_extra" rows="3" dir="ltr" style="text-align:left;" placeholder="Disallow: /private">{{ old('robots_extra', $seo['robots_extra'] ?? '') }}</textarea>
                </div>

                <h3 style="margin:18px 0 10px;">صفحه دامنه اصلی (Apex)</h3>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
                    <input type="checkbox" name="apex_enabled" value="1" @checked(old('apex_enabled', $seo['apex_enabled'] ?? '1') === '1')>
                    تولید / انتشار صفحهٔ دامنه فعال باشد
                </label>
                <div class="accept-row accept-row-2">
                    <div>
                        <label>تیتر صفحه دامنه</label>
                        <input type="text" name="apex_headline" value="{{ old('apex_headline', $seo['apex_headline'] ?? '') }}">
                    </div>
                    <div>
                        <label>متن دکمه</label>
                        <input type="text" name="apex_cta" value="{{ old('apex_cta', $seo['apex_cta'] ?? '') }}">
                    </div>
                </div>
                <div style="margin-top:10px;">
                    <label>متن کوتاه صفحه دامنه</label>
                    <textarea name="apex_lead" rows="2">{{ old('apex_lead', $seo['apex_lead'] ?? '') }}</textarea>
                </div>
                <div style="margin-top:10px;">
                    <label>آدرس ورود به سامانه (دکمه)</label>
                    <input type="url" name="apex_support_url" value="{{ old('apex_support_url', $seo['apex_support_url'] ?? '') }}" dir="ltr" style="text-align:left;" placeholder="https://support.hddsoftware.ir">
                </div>

                <div class="actions" style="margin-top:14px;display:flex;flex-wrap:wrap;gap:8px;">
                    <button class="btn btn-primary" type="submit">ذخیره تنظیمات SEO</button>
                </div>
            </form>

            <div class="panel" style="margin-top:12px;">
                <h3 style="margin:0 0 8px;">انتشار صفحه دامنه</h3>
                <p class="muted" style="margin:0 0 10px;font-size:13px;">اگر اپ روی هاست اشتراکی داخل پوشه‌ای مثل <code dir="ltr">public_html/support</code> باشد، دکمهٔ انتشار سعی می‌کند <code dir="ltr">public_html/index.html</code> را بسازد. در غیر این صورت فایل را دانلود و دستی آپلود کنید.</p>
                <div class="actions" style="display:flex;flex-wrap:wrap;gap:8px;">
                    <a class="btn btn-secondary" href="{{ route('settings.seo.apex-download') }}">دانلود index.html</a>
                    <form method="POST" action="{{ route('settings.seo.apex-publish') }}" style="display:inline;">
                        @csrf
                        <input type="hidden" name="settings_tab" value="seo">
                        <button class="btn btn-primary" type="submit">انتشار روی دامنه</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="ws-pane {{ $activeTab === 'users' ? 'active' : '' }}" data-ws-pane="users">
            <div class="emp-cartable-hero">
                <div>
                    <h2 style="margin:0;">کارتابل کارمندان</h2>
                    <p class="lead" style="margin:4px 0 0;">ورود با موبایل و تأیید SMS — دسترسی طبق وظیفه</p>
                </div>
                <div class="actions" style="margin:0;">
                    <a class="btn btn-primary" href="{{ route('employees.create') }}">کارمند جدید</a>
                    <a class="btn btn-secondary" href="{{ route('employees.index') }}">کارتابل کامل</a>
                </div>
            </div>

            <div class="emp-stat-row" style="margin-top:10px;">
                <div class="emp-stat"><span>کل</span><strong>{{ $users->count() }}</strong></div>
                <div class="emp-stat tone-ok"><span>فعال</span><strong>{{ $users->where('is_active', true)->count() }}</strong></div>
                <div class="emp-stat tone-sms"><span>ورود SMS</span><strong>{{ $users->where('can_login_otp', true)->count() }}</strong></div>
                <div class="emp-stat tone-pass"><span>ورود رمز</span><strong>{{ $users->where('can_login_password', true)->count() }}</strong></div>
            </div>

            <div class="emp-card-grid" style="margin-top:10px;">
                @foreach($users->take(8) as $employee)
                    @php
                        $meta = \App\Support\Permissions::roleMeta($employee->role);
                        $tech = $employee->technician;
                    @endphp
                    <article class="emp-card tone-{{ $meta['tone'] }} {{ $employee->is_active ? '' : 'is-off' }}">
                        <header class="emp-card-head">
                            <div class="emp-avatar">{{ $meta['mark'] }}</div>
                            <div>
                                <strong>{{ $employee->name }}</strong>
                                <div class="emp-duty">{{ $meta['label'] }}</div>
                            </div>
                        </header>
                        <div class="emp-card-body">
                            <div class="emp-phone" dir="ltr">{{ $employee->phone ?: '—' }}</div>
                            <div class="emp-login-chips">
                                @if($employee->can_login_otp)<span class="chip chip-sms">موبایل / SMS</span>@endif
                                @if($employee->can_login_password)<span class="chip chip-pass">رمز</span>@endif
                            </div>
                            @if($tech)
                                <div class="emp-pay-box">
                                    <div><span class="muted">تخصص</span><strong>{{ $tech->specialty ?: '—' }}</strong></div>
                                    <div><span class="muted">درصد سود</span><strong>{{ (int) $tech->commission_percent }}٪</strong></div>
                                    <div><span class="muted">حقوق</span><strong dir="ltr">{{ number_format((int) ($tech->monthly_salary ?? 0)) }}</strong></div>
                                </div>
                            @endif
                        </div>
                        <footer class="emp-card-foot">
                            <a class="btn btn-secondary" href="{{ route('employees.edit', $employee) }}">دسترسی / وظیفه</a>
                        </footer>
                    </article>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection

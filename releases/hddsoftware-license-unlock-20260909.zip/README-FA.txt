آنلاک فوری support.hddsoftware.ir (ارور لایسنس + 404 روی install.php)
====================================================================

علت:
- سرور لایسنس (support.hdd-land.ir) مسیر /license/verify را ندارد (404)
- نسخه فعلی مشتری این پاسخ را قفل سخت می‌کند
- لینک /install.php به صفحه 404 می‌رود چون فایل نصب بعد از setup حذف شده

روش سریع (پیشنهادی):
1) محتویات پوشه paths/ را روی ریشه پروژه Laravel مشتری کپی کنید
   (روی app/ و resources/ و public/ موجود merge شود)
2) فایل public/_license_unlock.php را یک‌بار در مرورگر باز کنید:
   https://support.hddsoftware.ir/_license_unlock.php
3) خروجی باید DONE_UNLOCK_OK داشته باشد
4) همان فایل _license_unlock.php را حذف کنید
5) صفحه اصلی را سخت‌رفرش کنید

روش دستی بدون اسکریپت:
1) EnsureLicensed.php → app/Http/Middleware/EnsureLicensed.php
2) license.blade.php → resources/views/errors/license.blade.php
3) install.php → public/install.php
4) در Terminal هاست:
   php artisan optimize:clear

بعداً روی سرور فروشنده (support.hdd-land.ir) API لایسنس را Deploy کنید
تا verify واقعی کار کند؛ تا آن موقع مشتری با soft-fail باز می‌ماند.

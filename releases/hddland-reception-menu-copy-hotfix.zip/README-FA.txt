آپلود _reception_menu_hotfix.php و __reception_menu_payload کنار index.php سپس باز کردن URL با ?t=reception-menu-2026

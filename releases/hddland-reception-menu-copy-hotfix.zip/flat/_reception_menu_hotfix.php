<?php
header('Content-Type: text/plain; charset=utf-8');
$token = $_GET['t'] ?? '';
if ($token !== 'reception-menu-2026') { http_response_code(403); echo "forbidden\n"; exit; }
$public = __DIR__;
$root = is_file($public.'/../artisan') ? dirname($public) : (is_file($public.'/artisan') ? $public : null);
if (!$root) { echo "ERROR: Laravel root not found\n"; exit(1); }
echo "root={$root}\n";
$src = $public.'/__reception_menu_payload/plugins/MegaMenu/Plugin.php';
$dst = $root.'/plugins/MegaMenu/Plugin.php';
if (!is_file($src)) { echo "ERROR: missing payload Plugin.php\n"; exit(1); }
if (!is_dir(dirname($dst))) { echo "ERROR: missing plugins/MegaMenu on server\n"; exit(1); }
$bak = $dst.'.bak-reception-menu';
if (is_file($dst) && !is_file($bak)) { @copy($dst, $bak); }
$ok = @copy($src, $dst);
echo ($ok ? 'OK ' : 'FAIL ').'plugins/MegaMenu/Plugin.php'."\n";
$check = @file_get_contents($dst) ?: '';
echo 'has_menuItemBodyDefaults='.(str_contains($check, 'menuItemBodyDefaults') ? 'yes' : 'no')."\n";
echo 'has_remote_preorder='.(str_contains($check, 'remote-preorder') ? 'yes' : 'no')."\n";
echo 'mtime='.date('c', @filemtime($dst))."\n";
if (function_exists('opcache_reset')) { opcache_reset(); echo "opcache_reset=1\n"; }
// cleanup payload + self
function rrmdir($dir) {
  if (!is_dir($dir)) return;
  foreach (scandir($dir) as $f) {
    if ($f==='.'||$f==='..') continue;
    $p=$dir.'/'.$f;
    if (is_dir($p)) rrmdir($p); else @unlink($p);
  }
  @rmdir($dir);
}
rrmdir($public.'/__reception_menu_payload');
@unlink(__FILE__);
echo "DONE\n";

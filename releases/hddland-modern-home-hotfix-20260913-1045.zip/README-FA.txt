چرا هنوز بنر قدیمی و دو منوی شبیه هم می‌بینید؟
=============================================
کد روی GitHub/PR آماده است، ولی روی سرور hdd-land.ir آپلود نشده.
پنل ادمین فروشگاه فقط تنظیمات دیتابیس را عوض می‌کند و نمی‌تواند
فایل‌های PHP را جایگزین کند. ذخیره «بنر فعال» روی سرور فعلی HTTP 500 می‌دهد.

ورود ادمین با info@hdd-land.ir تأیید شد، اما:
- /admin/hero-studio هنوز 404 است
- صفحه اول هنوز hl-revolution-banner-wrap و CSS?v=9 دارد
- دو منو («استودیو قالب صفحه اول» و «بنرساز Revolution») هر دو به
  همان theme-builder می‌روند

نصب سریع (File Manager / FTP)
------------------------------
1) از پوشه paths/public/ این دو مورد را کنار index.php در public آپلود کنید:
   - _modern_home_hotfix.php
   - __modern_home_payload/
2) مرورگر: https://hdd-land.ir/_modern_home_hotfix.php
3) خروجی موفق باید داشته باشد:
   banner_live=0
   home_has_modern=1
   admin_has_hero_studio=1
   DONE
4) همان دو مورد را از public پاک کنید
5) Ctrl+F5 روی صفحه اول و ادمین

بعد از نصب
----------
- هیرو مدرن (hl-hero)، بدون Revolution
- CSS: home-corporate.css?v=13
- یک منو: استودیو هیرو مدرن → /admin/hero-studio

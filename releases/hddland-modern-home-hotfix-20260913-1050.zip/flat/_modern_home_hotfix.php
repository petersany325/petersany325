<?php
header('Content-Type: text/plain; charset=utf-8');
$public = __DIR__;
$root = is_file($public . '/../artisan') ? dirname($public) : (is_file($public . '/artisan') ? $public : null);
if (!$root) { echo "ERROR: Laravel root not found\n"; exit(1); }
echo "root={$root}\n";
$payload = $public . '/__modern_home_payload';
if (!is_dir($payload)) { echo "ERROR: missing __modern_home_payload/\n"; exit(1); }

function mirror_copy(string $src, string $dstRoot, array &$log): void {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $file) {
        $rel = substr($file->getPathname(), strlen($src) + 1);
        $target = $dstRoot . '/' . $rel;
        if ($file->isDir()) {
            if (!is_dir($target)) { @mkdir($target, 0755, true); }
            continue;
        }
        if (!is_dir(dirname($target))) { @mkdir(dirname($target), 0755, true); }
        $bak = $target . '.bak-modern-home';
        if (is_file($target) && !is_file($bak)) { @copy($target, $bak); }
        $log[] = (@copy($file->getPathname(), $target) ? 'OK ' : 'FAIL ') . $rel;
    }
}

$log = [];
mirror_copy($payload, $root, $log);
echo implode("\n", $log) . "\n";

if (is_file($root . '/vendor/autoload.php') && is_file($root . '/bootstrap/app.php')) {
    try {
        require $root . '/vendor/autoload.php';
        $app = require $root . '/bootstrap/app.php';
        $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
        try {
            if (class_exists(\App\Support\SettingsStore::class)) {
                \App\Support\SettingsStore::set('hero_use_legacy_banner', 0);
                echo "hero_use_legacy_banner=0\n";
            }
        } catch (Throwable $e) { echo 'flag_fail=' . $e->getMessage() . "\n"; }
        try { Illuminate\Support\Facades\Artisan::call('optimize:clear'); echo "optimize_clear_ok\n"; } catch (Throwable $e) { echo 'optimize_fail=' . $e->getMessage() . "\n"; }
        try { Illuminate\Support\Facades\Artisan::call('view:clear'); echo "view_clear_ok\n"; } catch (Throwable $e) {}
        try { Illuminate\Support\Facades\Cache::flush(); echo "cache_flush_ok\n"; } catch (Throwable $e) {}
        if (class_exists(\Plugins\ThemeBuilder\src\HomepageBanner::class)) {
            $r = \Plugins\ThemeBuilder\src\HomepageBanner::resolve();
            echo 'banner_live=' . (!empty($r['live']) ? '1' : '0') . "\n";
        } else {
            echo "HomepageBanner_missing\n";
        }
        $css = $root . '/public/css/home-corporate.css';
        echo 'css_bytes=' . (is_file($css) ? filesize($css) : 0) . "\n";
        $home = $root . '/resources/views/storefront/home.blade.php';
        $homeTxt = is_file($home) ? file_get_contents($home) : '';
        echo 'home_has_modern=' . (str_contains($homeTxt, 'home-hero') ? '1' : '0') . "\n";
        echo 'home_clean=' . ((str_contains($homeTxt, 'revolution') || str_contains($homeTxt, 'HomepageBanner')) ? '0' : '1') . "\n";
        $admin = $root . '/resources/views/layouts/admin.blade.php';
        $adminTxt = is_file($admin) ? file_get_contents($admin) : '';
        echo 'admin_has_hero_studio=' . (str_contains($adminTxt, 'hero-studio') ? '1' : '0') . "\n";
        echo 'admin_menu_modern=' . (str_contains($adminTxt, 'استودیو هیرو مدرن') ? '1' : '0') . "\n";
    } catch (Throwable $e) {
        echo 'bootstrap_fail=' . $e->getMessage() . "\n";
    }
}
echo "DONE — delete public/_modern_home_hotfix.php and public/__modern_home_payload/\n";
echo "Hard-refresh https://hdd-land.ir/ — expect home-corporate.css?v=13 and class hl-hero\n";
echo "Admin: https://hdd-land.ir/admin/hero-studio\n";

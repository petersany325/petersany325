<?php

use App\Http\Controllers\AccountingController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DailyLogController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeliveryController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\PartController;
use App\Http\Controllers\WarehouseController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReceptionController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\SmsStatusController;
use App\Http\Controllers\BackupCronController;
use App\Http\Controllers\BackupCloudController;
use App\Http\Controllers\SystemToolsController;
use App\Http\Controllers\TrashController;
use App\Http\Controllers\TechnicianController;
use App\Http\Controllers\Payment\ZarinPalController;
use App\Http\Controllers\PaymentReceiptController;
use App\Http\Controllers\Portal\PaymentReceiptController as PortalPaymentReceiptController;
use App\Http\Controllers\HandoffController;
use App\Http\Controllers\InternController;
use App\Http\Controllers\InternPortalController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\StaffSmsTemplateController;
use App\Http\Controllers\Portal\AuthController as PortalAuthController;
use App\Http\Controllers\Portal\CartableController as PortalCartableController;
use App\Http\Controllers\Portal\MessageController as PortalMessageController;
use App\Http\Controllers\LicenseApiController;
use App\Http\Middleware\EnsurePermission;
use App\Http\Middleware\EnsurePortalCustomer;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::post('/license/activate', [LicenseApiController::class, 'activate'])
    ->middleware('throttle:30,1')
    ->name('license.activate');
Route::post('/license/verify', [LicenseApiController::class, 'verify'])
    ->middleware('throttle:60,1')
    ->name('license.verify');

Route::get('/', function () {
    if (Auth::check()) {
        return redirect()->route(Auth::user()->homeRoute());
    }
    if (session('portal_customer_id')) {
        return redirect()->route('portal.home');
    }

    return response()
        ->view('gate')
        ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        ->header('Pragma', 'no-cache');
})->name('gate');

Route::redirect('/gate', '/');
Route::redirect('/portal', '/cartable');

Route::get('/a/{token}', [\App\Http\Controllers\CostApprovalController::class, 'show'])
    ->where('token', '[A-Za-z0-9]{20,80}')
    ->name('approvals.show');
Route::post('/a/{token}/approve', [\App\Http\Controllers\CostApprovalController::class, 'approve'])
    ->where('token', '[A-Za-z0-9]{20,80}')
    ->middleware('throttle:20,1')
    ->name('approvals.approve');
Route::post('/a/{token}/reject', [\App\Http\Controllers\CostApprovalController::class, 'reject'])
    ->where('token', '[A-Za-z0-9]{20,80}')
    ->middleware('throttle:20,1')
    ->name('approvals.reject');

Route::get('/payments/zarinpal/callback/{trx}', [ZarinPalController::class, 'callback'])
    ->name('payments.zarinpal.callback');

Route::get('/cron/backup', BackupCronController::class)
    ->middleware('throttle:30,1')
    ->name('cron.backup');

Route::prefix('cartable')->name('portal.')->group(function () {
    Route::get('/', [PortalAuthController::class, 'showLogin'])->name('login');
    Route::post('/otp/send', [PortalAuthController::class, 'sendOtp'])->name('otp.send');
    Route::post('/otp/verify', [PortalAuthController::class, 'verifyOtp'])->name('otp.verify');

    Route::middleware(EnsurePortalCustomer::class)->group(function () {
        Route::post('/logout', [PortalAuthController::class, 'logout'])->name('logout');
        Route::get('/home', [PortalCartableController::class, 'home'])->name('home');
        Route::get('/tickets', [PortalCartableController::class, 'tickets'])->name('tickets');
        Route::get('/search', [PortalCartableController::class, 'search'])->name('search');
        Route::get('/tickets/{reception}', [PortalCartableController::class, 'show'])->name('show');
        Route::get('/report', [PortalCartableController::class, 'report'])->name('report');
        Route::get('/approvals', [PortalCartableController::class, 'approvals'])->name('approvals');
        Route::get('/approvals/{approval}', [PortalCartableController::class, 'approvalShow'])->name('approvals.show');
        Route::get('/pay', [PortalCartableController::class, 'pay'])->name('pay');
        Route::post('/pay/{reception}/zarinpal', [ZarinPalController::class, 'start'])->name('zarinpal.start');
        Route::post('/tickets/{reception}/receipts', [PortalPaymentReceiptController::class, 'store'])->name('receipts.store');
        Route::get('/receipts/{receipt}/image', [PortalPaymentReceiptController::class, 'image'])->name('receipts.image');
        Route::get('/messages', [PortalMessageController::class, 'index'])->name('messages');
        Route::post('/messages', [PortalMessageController::class, 'store'])->name('messages.store');
    });
});

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/login/otp/send', [AuthController::class, 'sendOtp'])->name('login.otp.send');
    Route::post('/login/otp/verify', [AuthController::class, 'verifyOtp'])->name('login.otp.verify');
});


<?php
require __DIR__.'/web_part1.php';
require __DIR__.'/web_part2.php';

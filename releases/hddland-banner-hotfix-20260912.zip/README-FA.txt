چرا روی سایت اعمال نشد؟
========================
فیکس فقط داخل GitHub (PR #96) بود و روی سرور hdd-land.ir آپلود/Deploy نشده.
شواهد لایو همین الان:
- CSS هنوز home-corporate.css?v=4 است (فیکس v=9)
- هیرو هنوز «مرکز تخصصی هارد...» است (hl-hero)
- بنرساز شما «سرزمین هارد / سخت‌افزار مطمئن...» را فعال کرده ولی استورفرانت قدیمی آن را نادیده می‌گیرد

روش سریع آپلود (پیشنهادی)
--------------------------
1) محتویات پوشه paths/public/ را داخل Document Root سایت
   (همان جایی که index.php لاراول/public است) آپلود کنید:
   - _banner_hotfix.php
   - __banner_payload/  (با app و plugins و resources داخلش)
2) یک‌بار باز کنید:
   https://hdd-land.ir/_banner_hotfix.php
3) خروجی باید DONE و ترجیحاً banner_live=1 داشته باشد
4) هر دو _banner_hotfix.php و پوشه __banner_payload را حذف کنید
5) Hard Refresh صفحه اول

روش دستی
--------
محتویات paths/ (به‌جز public) را روی ریشه پروژه Laravel Merge کنید، بعد:
  php artisan optimize:clear

بعد از اعمال
------------
صفحه اول باید بنر Revolution (سرزمین هارد) را نشان دهد، نه hl-hero شرکتی.

@php
  $home = \App\Support\HomePageConfig::get();
  $trust = \App\Support\HomePageConfig::trustItems($home);
  $heroImage = \App\Support\HomePageConfig::imageUrl((string) ($home['hero_image'] ?? 'images/home/hero.jpg'));
  $mergeImage = \App\Support\HomePageConfig::imageUrl((string) ($home['hero_merge_image'] ?? ''));
  $layout = (string) ($home['hero_layout'] ?? 'split-rtl');

  // پل بنرساز → صفحه اول (اولویت با بنر زنده ThemeBuilder / Revolution)
  $resolved = ['live' => false, 'banner' => []];
  if (class_exists(\Plugins\ThemeBuilder\src\HomepageBanner::class)) {
    \Plugins\ThemeBuilder\src\HomepageBanner::ensureViewsRegistered();
    $resolved = \Plugins\ThemeBuilder\src\HomepageBanner::resolve();
  }
  $useRevolution = ! empty($resolved['live']);
  $revolutionBanner = is_array($resolved['banner'] ?? null) ? $resolved['banner'] : [];

  // اگر homepage از قبل Revolution را رندر کرده، دوباره نکش.
  $alreadyRendered = ! empty($revolutionAlreadyRendered) || ! empty($revolutionAlreadyRendered);
  $skipHero = ! empty($skipHero) || ! empty($skipHero) || $useRevolution;
@endphp

@if($useRevolution && ! $alreadyRendered)
  @php
    $bannerView = view()->exists('theme-builder::storefront.partials.banner')
      ? 'theme-builder::storefront.partials.banner'
      : (view()->exists('themebuilder::storefront.partials.banner') ? 'themebuilder::storefront.partials.banner' : null);
  @endphp
  @if($bannerView)
    @include($bannerView, ['b' => $revolutionBanner])
  @endif
@elseif(! $skipHero && ! empty($home['hero_enabled']))
<section
  class="hl-hero hl-hero--{{ $layout }}"
  aria-label="بنر فروشگاه و تأمین سازمانی"
  style="{{ \App\Support\HomePageConfig::heroStyleAttr($home) }}"
>
  <div class="hl-hero__stage">
    <div class="hl-hero__copy" data-hl-layer="copy">
      <div class="hl-kicker"><i></i> {{ $home['hero_kicker'] }}</div>
      <h1>{!! \App\Support\HomePageConfig::heroTitleHtml($home) !!}</h1>
      <p class="hl-hero__lead">{{ $home['hero_text'] }}</p>
      <div class="hl-hero__actions">
        <a class="btn-hl btn-hl-primary" href="{{ url($home['hero_cta1_url'] ?: '/products') }}">{{ $home['hero_cta1_label'] }}</a>
        <a class="btn-hl btn-hl-ghost" href="{{ url($home['hero_cta2_url'] ?: '/contact') }}">{{ $home['hero_cta2_label'] }}</a>
      </div>
    </div>
    <div class="hl-hero__media" data-hl-layer="media">
      <img src="{{ $heroImage }}" width="1350" height="900" alt="{{ $home['hero_title'] }}" fetchpriority="high" decoding="async">
      @if(!empty($home['hero_merge_enabled']) && $mergeImage !== '')
        <img class="hl-hero__merge" src="{{ $mergeImage }}" alt="" loading="lazy" decoding="async">
      @endif
    </div>
  </div>
</section>
@endif

@if(!empty($home['trust_enabled']) && $trust !== [])
<section class="hl-trust" aria-label="اعتماد">
  @foreach($trust as $item)
    <div class="hl-trust-item">
      <span class="hl-trust-ico" aria-hidden="true">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3 5 6v6c0 5 3.4 8.4 7 9 3.6-.6 7-4 7-9V6l-7-3z"/><path d="m9 12 2 2 4-4"/></svg>
      </span>
      <strong>{{ $item['title'] }}</strong>
      <span>{{ $item['text'] }}</span>
    </div>
  @endforeach
</section>
@endif

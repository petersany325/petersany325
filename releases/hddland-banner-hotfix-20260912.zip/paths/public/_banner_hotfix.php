<?php
/**
 * One-shot: apply Revolution→homepage bridge files, then DELETE this script.
 * Upload next to index.php (public/), open once in browser.
 */
header('Content-Type: text/plain; charset=utf-8');
$public = __DIR__;
$root = is_file($public.'/../artisan') ? dirname($public) : (is_file($public.'/artisan') ? $public : null);
if (!$root) { echo "ERROR: Laravel root not found\n"; exit(1); }
echo "root={$root}\n";

$payload = $public.'/__banner_payload';
if (!is_dir($payload)) {
    echo "ERROR: missing __banner_payload/ next to this script\n";
    exit(1);
}

function mirror_copy(string $src, string $dstRoot, array &$log): void {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $file) {
        $rel = substr($file->getPathname(), strlen($src) + 1);
        $target = $dstRoot.'/'.$rel;
        if ($file->isDir()) {
            if (!is_dir($target)) { @mkdir($target, 0755, true); }
            continue;
        }
        if (!is_dir(dirname($target))) { @mkdir(dirname($target), 0755, true); }
        $bak = $target.'.bak-banner-hotfix';
        if (is_file($target) && !is_file($bak)) { @copy($target, $bak); }
        if (@copy($file->getPathname(), $target)) { $log[] = 'OK '.$rel; }
        else { $log[] = 'FAIL '.$rel; }
    }
}

$log = [];
mirror_copy($payload, $root, $log);
echo implode("\n", $log)."\n";

if (is_file($root.'/vendor/autoload.php') && is_file($root.'/bootstrap/app.php')) {
    try {
        require $root.'/vendor/autoload.php';
        $app = require $root.'/bootstrap/app.php';
        $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
        Illuminate\Support\Facades\Artisan::call('optimize:clear');
        echo "optimize_clear_ok\n";
        try { Illuminate\Support\Facades\Cache::flush(); echo "cache_flush_ok\n"; } catch (Throwable $e) {}
        if (class_exists(\\Plugins\\ThemeBuilder\\src\\HomepageBanner::class)) {
            $r = \\Plugins\\ThemeBuilder\\src\\HomepageBanner::resolve();
            echo 'banner_live='.(!empty($r['live']) ? '1' : '0')."\n";
        } else {
            echo "HomepageBanner_class_missing_after_copy\n";
        }
    } catch (Throwable $e) {
        echo 'bootstrap_fail='.$e->getMessage()."\n";
    }
}
echo "DONE — delete public/_banner_hotfix.php and public/__banner_payload/\n";

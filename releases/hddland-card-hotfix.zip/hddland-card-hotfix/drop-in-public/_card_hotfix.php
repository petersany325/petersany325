<?php
declare(strict_types=1);
header('Content-Type: text/plain; charset=utf-8');
$root = __DIR__;
$payload = $root.DIRECTORY_SEPARATOR.'__card_payload';
if (!is_dir($payload)) { http_response_code(500); echo "MISSING_PAYLOAD\n"; exit; }
$project = is_dir($root.DIRECTORY_SEPARATOR.'app') ? $root : dirname($root);
$map = [
  'public/card' => $root.DIRECTORY_SEPARATOR.'card',
  'public/css/biz-card.css' => $root.DIRECTORY_SEPARATOR.'css'.DIRECTORY_SEPARATOR.'biz-card.css',
  'public/images/card' => $root.DIRECTORY_SEPARATOR.'images'.DIRECTORY_SEPARATOR.'card',
  'plugins/BizCard' => $project.DIRECTORY_SEPARATOR.'plugins'.DIRECTORY_SEPARATOR.'BizCard',
];
$ok=0;$fail=0;
foreach ($map as $rel=>$to) {
  $from = $payload.DIRECTORY_SEPARATOR.str_replace('/', DIRECTORY_SEPARATOR, $rel);
  if (!file_exists($from)) { echo "SKIP $rel\n"; continue; }
  $good = false;
  if (is_file($from)) {
    @mkdir(dirname($to), 0755, true);
    $good = @copy($from, $to);
  } else {
    $good = card_copy_dir($from, $to);
  }
  echo ($good?'OK ':'FAIL ').$rel."\n";
  $good ? $ok++ : $fail++;
}
echo ($fail===0?"DONE":"PARTIAL")." ok=$ok fail=$fail\nOPEN /card/\n";
function card_copy_dir($from,$to){
  if (!is_dir($to) && !@mkdir($to,0755,true) && !is_dir($to)) return false;
  $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
  foreach ($it as $item) {
    $dest = $to.DIRECTORY_SEPARATOR.$it->getSubPathName();
    if ($item->isDir()) { if (!is_dir($dest) && !@mkdir($dest,0755,true) && !is_dir($dest)) return false; }
    elseif (!@copy($item->getPathname(), $dest)) return false;
  }
  return true;
}

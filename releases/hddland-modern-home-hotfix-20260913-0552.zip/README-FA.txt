چرا تغییر روی سایت دیده نشد؟
============================
کد فقط روی GitHub بود و روی سرور آپلود نشده بود.
روی https://hdd-land.ir هنوز بنر Revolution و CSS?v=9 است
و /admin/hero-studio هم 404 است.

نصب سریع
---------
1) محتویات paths/public/ را داخل public سایت (کنار index.php) آپلود کنید:
   - _modern_home_hotfix.php
   - __modern_home_payload/
2) باز کنید: https://hdd-land.ir/_modern_home_hotfix.php
3) خروجی موفق باید شامل باشد:
   banner_live=0
   home_has_modern=1
   DONE
4) هر دو مورد بالا را پاک کنید
5) Ctrl+F5 روی صفحه اول

بعد از نصب
----------
- هیرو مدرن تمام‌عرض (کلاس hl-hero)
- بدون بنر Revolution
- CSS: home-corporate.css?v=13
- ادمین: /admin/hero-studio

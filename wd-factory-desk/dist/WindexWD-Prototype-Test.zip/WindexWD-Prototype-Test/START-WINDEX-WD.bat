@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  Windex WD — HamGap prototype
echo  ============================
echo  Opening UI...
echo  Tip: click "Demo unlock (14 days)" on the license gate.
echo.
start "" "%~dp0app\index.html"

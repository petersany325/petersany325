@echo off
chcp 65001 >nul
echo Legacy WdHd = Win7 32-bit lab only. Never on OS disk.
pause
start "" "%~dp0driver\WdHdSetup\WdHdSetup.exe"

@echo off
chcp 65001 >nul
echo.
echo  WD Drive PassThrough — LEGACY 32-bit ONLY (XP/Vista/Win7 x86)
echo  Do NOT install on the boot/OS disk controller.
echo  Win10/11 x64 is NOT supported by this driver.
echo.
pause
start "" "%~dp0driver\WdHdSetup\WdHdSetup.exe"

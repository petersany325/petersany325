Windex WD — Windows Desktop Test Pack (HamGap)
==============================================

دانلود:
https://github.com/petersany325/petersany325/raw/cursor/wd-factory-desk-ui-proto-a3a0/wd-factory-desk/dist/WindexWD-Prototype-Test.zip

1) START-WINDEX-WD.bat
   → باز شدن به‌صورت پنجره نرم‌افزار ویندوز (Edge App Mode)

2) Demo unlock یا File → License Settings
   → فعال‌سازی لایسنس / مسیر پروژه

3) مسیر پروژه:
   D:\test windex\FW
   D:\test windex\Backup

4) ساخت EXE واقعی روی ویندوز (Node.js):
   برو داخل پوشه app → BUILD-WINDOWS.bat

5) درایور قدیمی (فقط Win7 32bit آزمایشگاه):
   INSTALL-DRIVER.bat

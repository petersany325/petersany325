@echo off
chcp 65001 >nul
cd /d "%~dp0app"
where python >nul 2>&1
if %ERRORLEVEL%==0 (
  echo Starting http://127.0.0.1:8765/
  echo Press Ctrl+C to stop.
  start http://127.0.0.1:8765/
  python -m http.server 8765
  goto :eof
)
where py >nul 2>&1
if %ERRORLEVEL%==0 (
  start http://127.0.0.1:8765/
  py -m http.server 8765
  goto :eof
)
echo Python not found. Use START-WINDEX-WD.bat instead.
pause
